window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var body = document.getElementById("body");

var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky + 150) {
    navbar.classList.add("fixed");
    body.classList.add("fixed");
  } else {
    navbar.classList.remove("fixed");
    body.classList.remove("fixed");
  }
}


    function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }

    let acc = document.getElementsByClassName("accordion");
    let i;
    for (i = 0; i < acc.length; i++) {
        acc[i].addEventListener("click", function () {
            $(this).toggleClass('active');
        });
    }
    $('.owl-main').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        dots: true,
        rtl: true,
        items: 1,
        responsive: {
            0: {
                items: 1,
                margin: 35,
            },
            576: {
                items: 2,

            },
        }
    });
    $('.owl-customer').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        dots: false,
        rtl: true,
        items: 2,
        center: true,
        responsive: {
            0: {
                items: 2,
                margin: 15,
                center: false,
            },
            576: {
                items: 4,

            },
            767: {
                items: 6,
            }
        }
    });
    $(document).ready(function () {
        $(".code-btn").click(function () {
            let $ss = $(this).parent('.discount-code').find('.code input').val();
            var textArea = document.createElement("textarea");
            textArea.value = $ss;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand("Copy");
            textArea.remove();
            $(this).parent('.discount-code').find('.copy-coded').toggle('fast');
        });

    });
    
    $(window).on('load', function(){
		$(".se-pre-con").fadeOut("slow");;
    });
<!--
    function toggle_visibility(id) {
       var e = document.getElementById(id);
       if(e.style.display == 'block')
          e.style.display = 'none';
       else
          e.style.display = 'block';
    }
//-->
